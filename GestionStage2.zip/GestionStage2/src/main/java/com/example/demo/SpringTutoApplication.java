package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import com.example.demo.dao.StageRepository;
import com.example.demo.dao.UtilisateurRepository;

@SpringBootApplication
public class SpringTutoApplication {

	public static void main(String[] args) {
		ApplicationContext ctx = SpringApplication.run(SpringTutoApplication.class, args);
		StageRepository stageRepository = ctx.getBean(StageRepository.class);
		UtilisateurRepository utilisateurRepository = ctx.getBean(UtilisateurRepository.class);
	}
}
