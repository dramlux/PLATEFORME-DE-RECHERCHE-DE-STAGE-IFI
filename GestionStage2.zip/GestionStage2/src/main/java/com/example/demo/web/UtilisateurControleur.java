package com.example.demo.web;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestMethod;

import com.example.demo.dao.StageRepository;
import com.example.demo.dao.UtilisateurRepository;
import com.example.demo.entities.Stage;
import com.example.demo.entities.Utilisateur;

@Controller
@RequestMapping(value="/Utilisateur")
public class UtilisateurControleur {
	@Autowired
	private UtilisateurRepository utilisateurRepository; //autoinjection
	
	@RequestMapping(value="/verifier")
	public String verifier(String type, String login, String mdp) {
		Utilisateur utilisateur = utilisateurRepository.findByLogin(login);
		if (type.equals("Admin") &  utilisateur.getMdp().equals(mdp)) 
			return "stage/deposeur/listeStageProposer";
		else
			return "redirect:authentification";
	}
	
	@RequestMapping(value="/saveStage", method=RequestMethod.POST)
	public String saveStage(@Valid Utilisateur utilisateur, 
			BindingResult bindingResult){
		Utilisateur utilisateurBase = utilisateurRepository.findByLogin(utilisateur.getLogin());
		if (utilisateur.getType().equals("Admin") &  
				utilisateur.getMdp().equals(utilisateurBase.getMdp())) 
			return "stage/deposeur/listeStageProposer";
		else
			return "redirect:authentification";
	}
	
	@RequestMapping(value="/authentification")
	public String authentification(Model model) {
		model.addAttribute("utilisateur", new Utilisateur());
		return "stage/utilisateur/authentification";
	}
	
}
