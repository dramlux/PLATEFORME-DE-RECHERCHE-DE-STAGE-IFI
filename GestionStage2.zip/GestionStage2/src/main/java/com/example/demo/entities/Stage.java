package com.example.demo.entities;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.format.annotation.DateTimeFormat;

@Entity
public class Stage  implements Serializable {
	@Id
	@GeneratedValue
	private Long idStage;
	private String intituleStage;
	private String niveauStage;
	private String domaineStage;
	private String lieuStage;
	@Value("string value")
	private String descriptionStage;
	private String fichierStage;
	private String lienStage;
	@DateTimeFormat(pattern="yyyy-MM-dd")
	private Date dateCreationStage;
	@DateTimeFormat(pattern="yyyy-MM-dd")
	private Date dateDebutStage;
	private boolean statusStage;
	
	public Stage() {super();}
	
	public Stage(Long idStage, 
			     String intituleStage, 
			     String niveauStage, 
			     String domaineStage, 
			     String lieuStage,
			     String descriptionStage, 
			     String fichierStage, 
			     String lienStage,
			     Date dateCreationStage,
			     Date dateDebutStage,
			     boolean statusStage) {
		super();
		this.idStage = idStage;
		this.intituleStage = intituleStage;
		this.niveauStage = niveauStage;
		this.domaineStage = domaineStage;
		this.lieuStage = lieuStage;
		this.descriptionStage = descriptionStage;
		this.fichierStage = fichierStage;
		this.lienStage = lienStage;
		this.dateCreationStage = dateCreationStage;
		this.dateDebutStage = dateDebutStage;
		this.statusStage = statusStage;
	}

	public Long getIdStage() {return idStage;}
	public void setIdStage(Long idStage) {this.idStage = idStage;}

	public String getIntituleStage() {return intituleStage;}
	public void setIntituleStage(String intituleStage) {this.intituleStage = intituleStage;}

	public String getNiveauStage() {return niveauStage;}
	public void setNiveauStage(String niveauStage) {this.niveauStage = niveauStage;}

	public String getDomaineStage() {return domaineStage;}
	public void setDomaineStage(String domaineStage) {this.domaineStage = domaineStage;}

	public String getLieuStage() {return lieuStage;}
	public void setLieuStage(String lieuStage) {this.lieuStage = lieuStage;}

	public String getDescriptionStage() {return descriptionStage;}
	public void setDescriptionStage(String descriptionStage) {this.descriptionStage = descriptionStage;}

	public String getLienStage() {return lienStage;}
	public void setLienStage(String lienStage) {this.lienStage = lienStage;}

	public Date getDateCreationStage() {return dateCreationStage;}
	public void setDateCreationStage(Date dateCreationStage) {this.dateCreationStage = dateCreationStage;}

	public Date getDateDebutStage() {return dateDebutStage;}
	public void setDateDebutStage(Date dateDebutStage) {this.dateDebutStage = dateDebutStage;}

	public boolean isStatusStage() {return statusStage;}
	public void setStatusStage(boolean statusStage) {this.statusStage = statusStage;}

	public String getFichierStage() {return fichierStage;}
	public void setFichierStage(String fichierStage) {this.fichierStage = fichierStage;}
}
