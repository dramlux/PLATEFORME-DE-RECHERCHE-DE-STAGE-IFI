package com.example.demo.dao;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.example.demo.entities.Stage;
import com.example.demo.entities.Utilisateur;

public interface UtilisateurRepository
	extends JpaRepository<Utilisateur, Long> {
	
	
	public Utilisateur findByLogin(String login);
	//methode spring data
	//public Prestation findByQuantitePrestation(long idPrestation);
	//public List<Prestation> findByDesignationPrestation(String designationPrestation);
	//public Page<Prestation> findByDesignationPrestation(String designationPrestation, Pageable p);
	//public Page<Stage> findByStatusStage(boolean vs, Pageable p);
	
	//methode personnelle
	//@Query("select e from Prestation e where e.designationPrestation like :x")
	//public Page<Prestation> chercherPrestation(@Param("x")String mc, Pageable p);

	//@Query("select e from stage e where e.valideStage=true")
	//public Page<Stage> chercherStage(Pageable p);
	
	//@Query("select e from Etudiant e where e.dateNaissance > :x and e.dateNaissance < :y")
	//public List<Etudiant> chercherEtudiant(@Param("x")Date d1, @Param("y")Date d2);
}