package com.example.demo.web;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.bind.annotation.RequestMethod;

import com.example.demo.dao.StageRepository;
import com.example.demo.entities.Stage;


import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import org.apache.commons.io.IOUtils;
import org.springframework.http.MediaType;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import com.itextpdf.text.*;
import com.itextpdf.text.pdf.PdfWriter;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import javax.servlet.http.HttpServletResponse;
import java.io.*;

@Controller
@RequestMapping(value="/Stage")
public class StageControleur {
	@Autowired
	private StageRepository stageRepository; //autoinjection
	//private static final String FILE_PATH = "/home/nobby/workspace/sts/GestionStageOrder.1pdf";
	private static final String FILE_PATH = "/home/nobby/stage/";
    private static final String APPLICATION_PDF = "application/pdf";
	
	@Value("${dir.fichier}")
	private String fichierDir;
	
	@RequestMapping(value="/listeStageValide")
	public String listeStageValide(Model model
			, @RequestParam(name="page", defaultValue="0") int p
			, @RequestParam(name="motCle", defaultValue="") String mc
			, @RequestParam(name="motCle", defaultValue="") String mc2
			, @RequestParam(name="motCle", defaultValue="") String mc3) {
		//Page<Stage> listStage = stageRepository.findByStatusStage(true, new PageRequest(p, 5));
		
		Page<Stage> listStage = stageRepository.cherchertitreStage("%" + mc + "%","%" + mc2 + "%","%" + mc3 + "%", new PageRequest(p, 4));
		
		//Page<CompteEtudiant> listCompteEtudiant = compteEtudiantRepository.chercherCompteEtudiant("%" + mc + "%", new PageRequest(p, 3));
		
		int nbPageStage = listStage.getTotalPages();
		int[] pages = new int[nbPageStage];
		for(int i = 0 ; i < nbPageStage ; i++) pages[i]=i;
		
		model.addAttribute("pages", pages);
		model.addAttribute("pageStage", listStage);
		model.addAttribute("pageCourante", p);
		model.addAttribute("motCle", mc);
		
		return "stage/etudiant/listeStageValide";
	}
	
	@RequestMapping(value="/listeAttenteValidationStageProposer")
	public String listeAttenteValidationStageProposer(Model model
			, @RequestParam(name="page", defaultValue="0") int p
			, @RequestParam(name="motCle", defaultValue="") String mc) {
		//Page<Stage> listStage = stageRepository.findAll(new PageRequest(p, 5));
		
		
		
		Page<Stage> listStage = stageRepository.findAll(new PageRequest(p, 4));
		
		int nbPageStage = listStage.getTotalPages();
		int[] pages = new int[nbPageStage];
		for(int i = 0 ; i < nbPageStage ; i++) pages[i]=i;
		
		model.addAttribute("pages", pages);
		model.addAttribute("pageStage", listStage);
		model.addAttribute("pageCourante", p);
		model.addAttribute("motCle", mc);
		
		return "stage/administration/listeAttenteValidationStageProposer";
		//return "stage/administration/login";
	}
	
	@RequestMapping(value="/listeStageProposer")
	public String listeStageProposer(Model model
			, @RequestParam(name="page", defaultValue="0") int p
			, @RequestParam(name="motCle", defaultValue="") String mc) {
		//Page<Stage> listStage = stageRepository.findAll(new PageRequest(p, 5));
		Page<Stage> listStage = stageRepository.findAll(new PageRequest(p, 4));
		
		int nbPageStage = listStage.getTotalPages();
		int[] pages = new int[nbPageStage];
		for(int i = 0 ; i < nbPageStage ; i++) pages[i]=i;
		
		model.addAttribute("pages", pages);
		model.addAttribute("pageStage", listStage);
		model.addAttribute("pageCourante", p);
		model.addAttribute("motCle", mc);
		
		return "stage/deposeur/listeStageProposer";
	}
	
	@RequestMapping(value="/supprimerStage")
	public String supprimerStage(Long idStage) {
		stageRepository.delete(idStage);
		return "redirect:listeStageProposer";
	}
	
	//visualiserStage
	@RequestMapping(value="/visualiserStage")
	public String visualiserStage(Long idStage, Model model) {
		Stage stage = stageRepository.getOne(idStage);
		model.addAttribute("stage", stage);
		return "stage/administration/visualiserStage";
	}
	
	@RequestMapping(value="/editerStage")
	public String editerStage(Long idStage, Model model) {
		Stage stage = stageRepository.getOne(idStage);
		model.addAttribute("stage", stage);
		return "stage/deposeur/editerStage";
	}
	
	@RequestMapping(value="/validerStage", method=RequestMethod.POST)
	public String validerStage(@Valid Stage stage, 
			BindingResult bindingResult){
		
		if(bindingResult.hasErrors())
			return "stage/administration/visualiserStage";
		else{
			//stage.setStatusStage(true);
			stage.setFichierStage(stage.getIdStage().toString());
			stageRepository.save(stage);
			return "redirect:listeAttenteValidationStageProposer";
		}
	}
	
	@RequestMapping(value="/saveStage", method=RequestMethod.POST)
	public String saveStage(@Valid Stage stage, 
			BindingResult bindingResult,
			RedirectAttributes redirectAttributes,
			@RequestParam(name="fileDesc") MultipartFile file) throws Throwable, IOException {
		/*if (file.isEmpty()) {
            redirectAttributes.addFlashAttribute("message", "Please select a file to upload");
            return "redirect:uploadStatus";
        }*/
		if(bindingResult.hasErrors())
			return "stage/deposeur/formStage";
		else{
			stageRepository.save(stage);
			if(!file.isEmpty()) {
				try {
		            // Get the file and save it somewhere
		            byte[] bytes = file.getBytes();
		            //Path path = Paths.get(fichierDir + file.getOriginalFilename());
		            Path path = Paths.get(fichierDir + stage.getIdStage()  );
		            Files.write(path, bytes);

		            //redirectAttributes.addFlashAttribute("message",
		                    //"You successfully uploaded '" + file.getOriginalFilename() + "'");
		            stage.setFichierStage(stage.getIdStage().toString());
		            stageRepository.save(stage);
		            return "redirect:listeStageProposer";
		        } catch (IOException e) {
		            e.printStackTrace();
		            return "stage/deposeur/formStage";
		        }
			}
			return "redirect:listeStageProposer";
		}
	}
	
	@RequestMapping(value="/updateStage", method=RequestMethod.POST)
	public String updateStage(@Valid Stage stage, 
			BindingResult bindingResult,
			RedirectAttributes redirectAttributes,
			@RequestParam(name="fileDesc") MultipartFile file) throws Throwable, IOException {
		String oldNameFile = stage.getFichierStage();
		if(bindingResult.hasErrors())
			return "stage/deposeur/editerStage";
		else{
			stage.setFichierStage(stage.getIdStage().toString());
			//stageRepository.save(stage);
			if(!file.isEmpty()) {
				try {
		            byte[] bytes = file.getBytes();
		            Path path = Paths.get(fichierDir + stage.getIdStage()  );
		            Files.write(path, bytes);

		            //redirectAttributes.addFlashAttribute("message",
		                    //"You successfully uploaded '" + file.getOriginalFilename() + "'");
		            //stage.setFichierStage(stage.getIdStage().toString());
		            stageRepository.save(stage);
		            return "redirect:listeStageProposer";
		        } catch (IOException e) {
		            e.printStackTrace();
		            return "stage/deposeur/editerStage";
		        }
			}
			else {
				//stage.setFichierStage(stage.getIdStage().toString());
				stageRepository.save(stage);
				return "redirect:listeStageProposer";
			}	
		}

	}

	
	@RequestMapping(value="/formStage", method=RequestMethod.GET)
	public String formStage(Model model) {
		model.addAttribute("stage", new Stage());
		return "stage/deposeur/formStage";
	}
	
	@RequestMapping(value="/filtreStageProposer", method=RequestMethod.GET)
	public String filtreStageProposer(Model model) {
		model.addAttribute("stage", new Stage());
		return "stage/deposeur/formStage";
	}
	
	/*@RequestMapping(value="/getFichier", 
			produces=MediaType.IMAGE_JPEG_VALUE)
	@ResponseBody
	public byte[] getFichier(Long idStage) throws FileNotFoundException, IOException {
		File f = new File(fichierDir+idStage);
		return IOUtils.toByteArray(new FileInputStream(f));
	}*/
	
	@RequestMapping(value="/getFichier", 
			produces=MediaType.IMAGE_JPEG_VALUE)
	@ResponseBody
	public String getFichier(Long idStage) throws FileNotFoundException, IOException {
		File f = new File(fichierDir+idStage);
		return f.getName();
	}
	
	@RequestMapping(value="/voirDescription2", method=RequestMethod.GET)
	public String voirDescription2(Long idStage) {
		return "stage/etudiant/descriptionStage";
	}
	
	private File getFile(String idStage) throws FileNotFoundException {
        File file = new File(FILE_PATH + idStage);
        if (!file.exists()){
            //throw new FileNotFoundException("file with path: " + FILE_PATH + " was not found.");
        	return null;
        }
        return file;
    }
	
	@RequestMapping(value = "/downloadA", method = RequestMethod.GET, produces = APPLICATION_PDF)
    public @ResponseBody void downloadA(HttpServletResponse response,
    		Long idStage) throws IOException {
        File file = getFile(idStage.toString());
        if (file != null) {
            InputStream in = new FileInputStream(file);

            response.setContentType(APPLICATION_PDF);
            response.setHeader("Content-Disposition", "attachment; filename=" + file.getName());
            response.setHeader("Content-Length", String.valueOf(file.length()));
            FileCopyUtils.copy(in, response.getOutputStream());
        }
    }
	
    @GetMapping("/uploadStatus")
    public String uploadStatus() {
        return "uploadStatus";
    }
}
