package com.example.demo.entities;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.format.annotation.DateTimeFormat;

@Entity
public class Utilisateur  implements Serializable {
	@Id
	@GeneratedValue
	private Long idUtilisateur;
	private String nom;
	private String prenom;
	private String entreprise;
	private String login;
	private String type;
	private String mdp;
	@DateTimeFormat(pattern="yyyy-MM-dd")
	private Date dateCreationStage;
	
	public Utilisateur() {super();}

	public Utilisateur(Long idUtilisateur, 
			           String nom, 
			           String prenom, 
			           String entreprise, 
			           String login, 
			           String type,
			           String mdp, 
			           Date dateCreationStage) {
		super();
		this.idUtilisateur = idUtilisateur;
		this.nom = nom;
		this.prenom = prenom;
		this.entreprise = entreprise;
		this.login = login;
		this.type = type;
		this.mdp = mdp;
		this.dateCreationStage = dateCreationStage;
	}

	public Long getIdUtilisateur() {return idUtilisateur;}
	public void setIdUtilisateur(Long idUtilisateur) {this.idUtilisateur = idUtilisateur;}

	public String getNom() {return nom;}
	public void setNom(String nom) {this.nom = nom;}

	public String getPrenom() {return prenom;}
	public void setPrenom(String prenom) {this.prenom = prenom;}

	public String getEntreprise() {return entreprise;}
	public void setEntreprise(String entreprise) {this.entreprise = entreprise;}

	public String getLogin() {return login;}
	public void setLogin(String login) {this.login = login;}

	public String getType() {return type;}
	public void setType(String type) {this.type = type;}

	public String getMdp() {return mdp;}
	public void setMdp(String mdp) {this.mdp = mdp;}

	public Date getDateCreationStage() {return dateCreationStage;}
	public void setDateCreationStage(Date dateCreationStage) {this.dateCreationStage = dateCreationStage;}
}
